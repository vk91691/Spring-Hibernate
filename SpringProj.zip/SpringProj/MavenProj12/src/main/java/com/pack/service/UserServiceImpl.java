package com.pack.service;

import com.pack.model.User;

public class UserServiceImpl implements UserService{

	public void add(User u)
	{
		System.out.println("User Added Successfully");
	}
}
