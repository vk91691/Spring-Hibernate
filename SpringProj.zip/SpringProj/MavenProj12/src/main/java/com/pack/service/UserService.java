package com.pack.service;


import com.pack.model.User;

public interface UserService {
	public void add(User u);
	
	
}
