package com.pack;

public class SecondBean {

	public SecondBean() {
		super();
		System.out.println("Inside seconbean");
	}
	public void check1() {
		System.out.println("Hello");
	}
}
