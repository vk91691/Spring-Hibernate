package com.pack;


import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		AbstractApplicationContext fact=new ClassPathXmlApplicationContext("beans.xml");
		HelloWorld h=(HelloWorld)fact.getBean("sample");
		System.out.println(h.getMessage());
		fact.registerShutdownHook();
	}

}
