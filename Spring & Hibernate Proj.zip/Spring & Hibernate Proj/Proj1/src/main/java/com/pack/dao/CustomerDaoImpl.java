package com.pack.dao;

import java.util.List;

import org.apache.log4j.Logger;
import org.hibernate.Query;
import org.hibernate.SessionFactory;
import org.springframework.stereotype.Repository;

import com.pack.form.Customer;
import com.pack.service.CustomerServiceImpl;


@Repository
public class CustomerDaoImpl implements CustomerDao {
	private static Logger log = Logger.getLogger(CustomerServiceImpl.class);

	private SessionFactory sessionFactory;
	
	public void setSessionFactory(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}

	@Override
	public void addCustomer(Customer c) {
		// TODO Auto-generated method stub
		sessionFactory.getCurrentSession().save(c);
		log.info("Inside Service");
	}

	@Override
	public void updateCustomer(Customer c) {
		// TODO Auto-generated method stub
		log.info("Updating");
		sessionFactory.getCurrentSession().update(c);
	}

	@Override
	public List<Customer> listCustomer() {
		// TODO Auto-generated method stub
		Query q=sessionFactory.getCurrentSession().createQuery("from Customer");
		List l=q.list();
		return l;
	}

	@Override
	public Customer getCustomerById(Integer cid) {
		// TODO Auto-generated method stub
		Query q=sessionFactory.getCurrentSession().createQuery("from Customer c where c.id=:id");
		q.setParameter("id",cid);
		Customer c=(Customer)q.uniqueResult();
		return c;
	}

	@Override
	public void removeCustomer(Integer cid) {
		// TODO Auto-generated method stub
		Customer c=(Customer)sessionFactory.getCurrentSession().get(Customer.class, cid);
		if(c!=null)
		{
			sessionFactory.getCurrentSession().delete(c);
		}
	}

}
