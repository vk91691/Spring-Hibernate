package com.pack;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

public class Main1 {

	static final Logger logger=Logger.getLogger(Main1.class);
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		PropertyConfigurator.configure("log4j.properties");
		logger.debug("debug");
		logger.error("Error");
		logger.fatal("fatal");
		logger.info("info");
		logger.warn("warn");
	}

}
