package com.pack;

import org.apache.log4j.BasicConfigurator;
import org.apache.log4j.Logger;

public class Main {
	static final Logger logger=Logger.getLogger(Main.class);
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		BasicConfigurator.configure();
		logger.debug("debug");
		logger.error("Error");
		logger.fatal("fatal");
		logger.info("info");
		logger.warn("warn");
	}

}
