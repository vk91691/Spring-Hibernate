package com.cognizant.grizzlystore.exception;

public class IgrizzlyException {

	public static String DRIVER_MISSING_ERROR="Driver is missing.";
	public static String SOME_SQL_ERROR="Some sql Errors contact to admin.";
	public static String CONTACT_TO_ADMIN_ERROR="Please contact to admin";
	public static String REGISTER_ADMIN_ERROR="Error while registering contact to admin";
	public static String CLOSING_RESOURCE_ERROR="Error while resource access contact to admin";

}
