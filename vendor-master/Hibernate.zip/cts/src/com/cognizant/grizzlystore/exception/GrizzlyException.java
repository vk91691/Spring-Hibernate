package com.cognizant.grizzlystore.exception;

public class GrizzlyException extends Exception {

	public GrizzlyException() {
		// TODO Auto-generated constructor stub
		super();
		
	}
	public GrizzlyException(String message, Throwable cause) {
		super(message, cause);
	}
	public GrizzlyException(String message) {
		super(message);
	}
	public GrizzlyException(Throwable cause) {
		super(cause);
	}

}
