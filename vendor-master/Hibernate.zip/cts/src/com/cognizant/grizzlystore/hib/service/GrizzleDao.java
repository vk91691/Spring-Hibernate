package com.cognizant.grizzlystore.hib.service;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.transaction.Transactional;

import com.cognizant.grizzlystore.exception.GrizzlyException;
import com.cognizant.grizzlystore.model.LoginDetails;
import com.cognizant.grizzlystore.model.ProductDetails;
import com.cognizant.grizzlystore.services.ILoginDao;
import com.cognizant.grizzlystore.services.IProductDao;


public class GrizzleDao implements ILoginDao, IProductDao {


	@PersistenceContext
	private EntityManager entityManager;
	@Override
	@Transactional
	public int saveProductDetails(ProductDetails productDetails) throws GrizzlyException {
		entityManager.persist(productDetails);
		return 1;
	}

	@Override
	@Transactional
	public ProductDetails getProductById(int pid) throws GrizzlyException {
		// TODO Auto-generated method stub
		ProductDetails details=entityManager.find(ProductDetails.class,pid);
		return details;
	}
/*
	@Override
	public int updateProduct(int[] pid, String status) throws GrizzlyException {
		entityManger.persist(ProductDetails);
		return 1;
	}
*/
	@Override
	@Transactional
	public int deleteProductDetails(int[] pid) throws GrizzlyException {
		ProductDetails details=entityManager.find(ProductDetails.class,pid);
		entityManager.remove(details);
		return 1;
	}

	@Override
	@Transactional
	public List<ProductDetails> getAllProductDetails(String filter) throws GrizzlyException {
		// TODO Auto-generated method stub
		TypedQuery<ProductDetails> query=entityManager.createQuery("select p from ProductDetails p",ProductDetails.class);
		List<ProductDetails> list=query.getResultList();
		return list;
	}

	@Override
	@Transactional
	public int doLogin(LoginDetails loginDetails) throws GrizzlyException {
		TypedQuery<LoginDetails> query=entityManager.createQuery("select 1.username,1.password from LoginDetails 1 where 1.username=? and 1.password=?",LoginDetails.class);
		query.setParameter(1, loginDetails.getUsername());
		query.setParameter(2, loginDetails.getPassword());
		int flag=0;
		LoginDetails dbLoginDetails=query.getSingleResult();
		if(dbLoginDetails!=null)
		{
			System.out.println("Logged in");
			flag=1;
		}
		else
		{
			System.out.println("user not available");
		}
		return flag;
	}

	@Override
	public int updateProduct(int[] pid, String status) throws GrizzlyException {
		// TODO Auto-generated method stub
		return 0;
	}


}
