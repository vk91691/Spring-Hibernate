package com.cognizant.grizzlystore.hib.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cognizant.grizzlystore.exception.GrizzlyException;
import com.cognizant.grizzlystore.model.LoginDetails;
import com.cognizant.grizzlystore.model.ProductDetails;
import com.cognizant.grizzlystore.services.ILoginDao;
import com.cognizant.grizzlystore.services.IProductDao;


@Service("grizzleHbService")
public class GrizzleHbService implements IProductDao, ILoginDao {

	@Autowired
	IProductDao iProductDao;
	@Autowired
	ILoginDao iLoginDao;
	public GrizzleHbService() {
		// TODO Auto-generated constructor stub

	}

	@Override
	public int doLogin(LoginDetails loginDetails) throws GrizzlyException {
		// TODO Auto-generated method stub
		System.out.println("Check Hib");
		return iLoginDao.doLogin(loginDetails);
	}

	@Override
	public int saveProductDetails(ProductDetails productDetails) throws GrizzlyException {
		// TODO Auto-generated method stub
		System.out.println(iProductDao);
		System.out.println("Save Hib");
		return iProductDao.saveProductDetails(productDetails);
	}

	@Override
	public ProductDetails getProductById(int pid) throws GrizzlyException {
		// TODO Auto-generated method stub
		System.out.println("get hib");
		return iProductDao.getProductById(pid);
	}

	@Override
	public int updateProduct(int[] pid, String status) throws GrizzlyException {
		// TODO Auto-generated method stub
		System.out.println("update hib");
		return iProductDao.updateProduct(pid, status);
		
	}

	@Override
	public int deleteProductDetails(int[] pid) throws GrizzlyException {
		// TODO Auto-generated method stub
		System.out.println("delete hib");
		return iProductDao.deleteProductDetails(pid);
	}

	@Override
	public List<ProductDetails> getAllProductDetails(String filter) throws GrizzlyException {
		// TODO Auto-generated method stub
		System.out.println("get hib");
		return iProductDao.getAllProductDetails(filter);
	}

}
