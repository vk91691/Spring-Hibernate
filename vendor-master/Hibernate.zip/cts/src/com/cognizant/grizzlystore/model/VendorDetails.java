package com.cognizant.grizzlystore.model;

public class VendorDetails {
      
	private int vendorId;
	
	private int quantity;
}
