package com.cognizant.grizzlystore.jpa;

import java.util.List;

import javax.management.Query;
import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;
import javax.persistence.TypedQuery;

import com.cognizant.grizzlystore.exception.GrizzlyException;
import com.cognizant.grizzlystore.model.LoginDetails;
import com.cognizant.grizzlystore.model.ProductDetails;
import com.cognizant.grizzlystore.services.ILoginDao;
import com.cognizant.grizzlystore.services.IProductDao;

public class GrizzleDao implements ILoginDao, IProductDao {

	public GrizzleDao() {
		// TODO Auto-generated constructor stub
	}
	EntityManager entityManager;

	@Override
	public int saveProductDetails(ProductDetails productDetails) throws GrizzlyException {
		// TODO Auto-generated method stub
		EntityTransaction t=entityManager.getTransaction();
		t.begin();
		entityManager.merge(productDetails);
		t.commit();
		return 0;
	}

	@Override
	public ProductDetails getProductById(int pid) throws GrizzlyException {
		// TODO Auto-generated method stub
		ProductDetails details=entityManager.find(ProductDetails.class, pid);
		return details;
	}

	@Override
	public int updateProduct(int[] pid, String status) throws GrizzlyException {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int deleteProductDetails(int[] pid) throws GrizzlyException {
		// TODO Auto-generated method stub
		int flag=0;
		EntityTransaction t=entityManager.getTransaction();
		t.begin();
		ProductDetails details=entityManager.find(ProductDetails.class, pid);
		t.commit();
		if(details!=null)
		{
			flag=1;
		}
		else
		{
			
		}
		return flag;
	}

	@Override
	public List<ProductDetails> getAllProductDetails(String filter) throws GrizzlyException {
		// TODO Auto-generated method stub
		List<ProductDetails> list=null;
		TypedQuery<ProductDetails> query=entityManager.createQuery("select p from ProductDetails p",ProductDetails.class);
		list=query.getResultList();
		return list;
	}

	@Override
	public int doLogin(LoginDetails loginDetails) throws GrizzlyException {
		// TODO Auto-generated method stub
		int flag=0;
		String hql="select l.username,l.password from LoginDetails l where l.username=? and l.password=?";
        javax.persistence.Query query=entityManager.createQuery(hql);
        query.setParameter(0, loginDetails.getUsername());
        query.setParameter(1, loginDetails.getPassword());
        System.out.println("Result"+query.getSingleResult());
        List<Object[]> l=query.getResultList();
        if(l!=null)
        {
        	System.out.println("Logged in");
        	flag=1;
        }
        else
        {
        	System.out.println("User not logged in");
        }
        
		return flag;
	}

}
