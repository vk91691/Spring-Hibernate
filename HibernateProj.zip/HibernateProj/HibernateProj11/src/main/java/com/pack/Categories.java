package com.pack;

import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.Table;

@Entity
@Table(name="many1")
public class Categories {
	@Id
	private int citid;
	private String citname;
	@ManyToMany(targetEntity=Item.class,cascade=CascadeType.ALL)
	@JoinTable(name="categories_items",joinColumns=@JoinColumn (name="cat_id_fk",referencedColumnName="citid"),inverseJoinColumns=@JoinColumn
			(name="item_id_fk",referencedColumnName="itemid"))
	private Set items;
	
	public Set getItems() {
		return items;
	}
	public void setItems(Set items) {
		this.items = items;
	}
	public int getCitid() {
		return citid;
	}
	public void setCitid(int citid) {
		this.citid = citid;
	}
	public String getCitname() {
		return citname;
	}
	public void setCitname(String citname) {
		this.citname = citname;
	}
	
	
}
