package com.pack;

import java.util.HashSet;
import java.util.Set;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.AnnotationConfiguration;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		SessionFactory sf=new AnnotationConfiguration().configure().buildSessionFactory();
		Session s=sf.openSession();
		Transaction t=s.beginTransaction();
		Categories c1=new Categories();
		c1.setCitid(100);
		c1.setCitname("VK");
		
		Categories c2=new Categories();
		c2.setCitid(110);
		c2.setCitname("VMK");
		
		Item i1=new Item();
		i1.setItemid(102);
		i1.setItemname("frag");
		
		Item i2=new Item();
		i2.setItemid(104);
		i2.setItemname("flag");
		
		Set s1=new HashSet();
		s1.add(i1);
		s1.add(i2);
		c1.setItems(s1);
		c2.setItems(s1);
		s.persist(c1);
		s.persist(c2);
		t.commit();
		System.out.println("INSERTED");
		s.close();
	}

}
