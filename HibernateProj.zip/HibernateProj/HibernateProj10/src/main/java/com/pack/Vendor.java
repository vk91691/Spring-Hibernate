package com.pack;

import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name = "ven11")
public class Vendor {

	@OneToMany(fetch=FetchType.LAZY, targetEntity=Customer.class,cascade=CascadeType.ALL)
	@JoinColumn(name="venid",referencedColumnName="vid")
	private Set customer;

	@Id
	@Column(name = "vid")
	private int vendor_id;
	@Column(name = "vname")
	private String vendor_name;

	public Set getCustomer() {
		return customer;
	}

	public void setCustomer(Set customer) {
		this.customer = customer;
	}

	public int getVendor_id() {
		return vendor_id;
	}

	public void setVendor_id(int vendor_id) {
		this.vendor_id = vendor_id;
	}

	public String getVendor_name() {
		return vendor_name;
	}

	public void setVendor_name(String vendor_name) {
		this.vendor_name = vendor_name;
	}

}
