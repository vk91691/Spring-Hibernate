package com.pack;

import java.util.HashSet;
import java.util.Set;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.AnnotationConfiguration;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		SessionFactory sf=new AnnotationConfiguration().configure().buildSessionFactory();
		Session s=sf.openSession();
		Transaction t=s.beginTransaction();
		Vendor v=new Vendor();
		v.setVendor_id(100);
		v.setVendor_name("VK");
		
		Customer c1=new Customer();
		c1.setCustomer_id(200);
		c1.setCustomer_name("SAM");
		
		Customer c2=new Customer();
		c2.setCustomer_id(300);
		c2.setCustomer_name("RAM");
		
		Set s1=new HashSet();
		s1.add(c1);
		s1.add(c2);
		
		v.setCustomer(s1);
		
		s.persist(v);
		t.commit();
		System.out.println("INSERTED");
		s.close();
	}

}
