package com.pack;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		SessionFactory sf=new Configuration().configure().buildSessionFactory();
		Session s=sf.openSession();
		Transaction t=s.beginTransaction();
		Student st=new Student();
		st.setStudent_id(100);
		st.setStudent_name("VK");
		st.setGroup("MATHS");
		
		Address ad=new Address();
		ad.setAddress_id(101);
		ad.setPlace("KRR");
		ad.setStudent(st);
		s.persist(ad);
		t.commit();
		System.out.println("INSERTED");
		s.close();
		
	}

}
